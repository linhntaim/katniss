/**
 * Created by Nguyen Tuan Linh on 2015-11-19.
 */
CKEDITOR.plugins.setLang('videodetector', 'vi', {
    title : 'Chèn đường dẫn video từ Youtube, Vimeo, hoặc Dailymotion',
    basic_settings : 'Thiết lập cơ bản',
    url_video_label : 'Đường dẫn Youtube, Vimeo hoặc Dailymotion',
    empty : 'Trống!'
});