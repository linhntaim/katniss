<?php

namespace Katniss\Http\Controllers\Admin;

use Katniss\Models\Category;
use Katniss\Models\Helpers\AppConfig;
use Katniss\Models\Helpers\QueryStringBuilder;
use Katniss\Models\Helpers\PaginationHelper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Katniss\Http\Controllers\MultipleLocaleContentController;


class LinkCategoryController extends MultipleLocaleContentController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $categories = Category::where('type', Category::LINK)->orderBy('created_at', 'desc')->paginate(AppConfig::DEFAULT_ITEMS_PER_PAGE);

        $query = new QueryStringBuilder([
            'page' => $categories->currentPage()
        ], adminUrl('link-categories'));
        return view($this->themePage('link_categories.list'), [
            'categories' => $categories,
            'query' => $query,
            'page_helper' => new PaginationHelper($categories->lastPage(), $categories->currentPage(), $categories->perPage()),
            'rdr_param' => rdrQueryParam($request->fullUrl()),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view($this->themePage('link_categories.add'), [
            'categories' => Category::where('type', Category::LINK)->get()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateMultipleLocaleData($request, ['name', 'slug', 'description'], [
            'name' => 'required',
            'slug' => 'required|unique:category_translations,slug',
        ], $data, $successes, $fails, $old);

        $error_redirect = redirect(adminUrl('link-categories/add'))
            ->withInput($old);

        if (count($successes) <= 0 && count($fails) > 0) {
            return $error_redirect->withErrors($fails[0]);
        }

        $parent_id = intval($request->input('parent'), 0);
        if ($parent_id != 0) {
            $validator = Validator::make($request->all(), [
                'parent' => 'sometimes|exists:categories,id,type,' . Category::LINK,
            ]);
            if ($validator->fails()) {
                return $error_redirect->withErrors($validator);
            }
        }

        $category = new Category();
        $category->type = Category::LINK;
        if ($parent_id != 0) {
            $category->parent_id = $parent_id;
        }
        foreach ($successes as $locale) {
            $transData = $data[$locale];
            $trans = $category->translateOrNew($locale);
            $trans->name = $transData['name'];
            $trans->slug = $transData['slug'];
            $trans->description = $transData['description'];
        }
        if ($category->save() === false) {
            return $error_redirect->withErrors([trans('error.database_insert')]);
        }

        return redirect(adminUrl('link-categories'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        $category = Category::findOrFail($id);

        if ($category->type != Category::LINK) {
            abort(404);
        }
        return view($this->themePage('link_categories.edit'), [
            'category' => $category,
            'categories' => Category::where('type', Category::LINK)->get(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $category = Category::findOrFail($request->input('id'));
        if ($category->type != Category::LINK) {
            abort(404);
        }

        $redirect = redirect(adminUrl('link-categories/{id}/edit', ['id' => $category->id]));

        $this->validateMultipleLocaleData($request, ['name', 'slug', 'description'], [
            'name' => 'required',
            'slug' => 'required|unique:category_translations,slug,' . $category->id . ',category_id',
        ], $data, $successes, $fails, $old);

        if (count($successes) <= 0 && count($fails) > 0) {
            return $redirect->withErrors($fails[0]);
        }

        $parent_id = intval($request->input('parent'), 0);
        if ($parent_id != 0) {
            $validator = Validator::make($request->all(), [
                'parent' => 'sometimes|exists:categories,id,type,' . Category::LINK
            ]);
            if ($validator->fails()) {
                return $redirect->withErrors($validator);
            }
        }
        $category->parent_id = $parent_id != 0 && $parent_id !== $category->parent_id ? $parent_id : null;
        foreach ($successes as $locale) {
            $transData = $data[$locale];
            $trans = $category->translateOrNew($locale);
            $trans->name = $transData['name'];
            $trans->slug = $transData['slug'];
            $trans->description = $transData['description'];
        }
        if ($category->save() === false) {
            return $redirect->withErrors([trans('error.database_update')]);
        }

        return redirect(adminUrl('link-categories'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $category = Category::where('type', Category::LINK)->where('id', $id)->firstOrFail();
        if ($category->type != Category::LINK) {
            abort(404);
        }

        $redirect_url = adminUrl('link-categories');
        $rdr = $request->session()->pull(AppConfig::KEY_REDIRECT_URL, '');
        if (!empty($rdr)) {
            $redirect_url = $rdr;
        }

        if ($category->links()->count() <= 0) {
            $success = true;
            DB::beginTransaction();
            try {
                Category::where('parent_id', $id)->update(['parent_id' => null]);
                $category->delete();
                DB::commit();
            } catch (\Exception $ex) {
                DB::rollBack();
                $success = false;
            }

            return $success ? redirect($redirect_url) : redirect($redirect_url)->withErrors([trans('error.database_delete')]);
        }

        return redirect($redirect_url)->withErrors([trans('error.category_not_empty')]);
    }

    public function layoutSort(Request $request, $id)
    {
        $category = Category::where('type', Category::LINK)->where('id', $id)->firstOrFail();

        return view($this->themePage('link_categories.sort'), [
            'category' => $category,
            'links' => $category->links,
        ]);
    }
}
