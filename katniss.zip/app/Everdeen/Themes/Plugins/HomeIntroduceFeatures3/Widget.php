<?php
namespace Katniss\Everdeen\Themes\Plugins\HomeIntroduceFeatures3;

use Katniss\Everdeen\Themes\Plugins\BaseLinks\Widget as BaseLinks;

class Widget extends BaseLinks
{
    const NAME = 'home_introduce_features_3';
    const DISPLAY_NAME = 'Home Introduce Features 3';

    public function register()
    {
    }
}
