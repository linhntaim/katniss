<?php
namespace Katniss\Everdeen\Themes\Plugins\FooterLinks;

use Katniss\Everdeen\Themes\Plugins\BaseLinks\Widget as BaseLinks;

class Widget extends BaseLinks
{
    const NAME = 'footer_links';
    const DISPLAY_NAME = 'Footer Links';
}
