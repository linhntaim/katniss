<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-08-18
 * Time: 23:11
 */

namespace Katniss\Everdeen\Http\Controllers;

class ApiController extends KatnissController
{
    use ApiResponseTrait;
}