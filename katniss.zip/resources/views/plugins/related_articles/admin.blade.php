<div class="box">
    <div class="box-body">
        <div class="form-group">
            <label for="inputNumberOfItems">{{ trans('related_articles.number_of_items') }}</label>
            <input id="inputNumberOfItems" type="number" class="form-control"
                   name="number_of_items" value="{{ $number_of_items }}">
        </div>
    </div>
</div>