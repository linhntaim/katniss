<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-12-09
 * Time: 00:07
 */
return [
    'page_contact_forms_title' => 'Thông tin liên lạc',
    'page_contact_forms_desc' => 'Quản lý dữ liệu thông tin liên lạc',
    'contact_form' => 'Thông tin liên lạc',
];