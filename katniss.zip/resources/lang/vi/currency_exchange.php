<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-05-21
 * Time: 21:07
 */

return [
    'exchange_rate' => 'Tỉ giá giao dịch',
    'main_currency' => 'Tiền tệ mặc định',
    'change_here' => '<a href=":url">Thay đổi ở đây</a>'
];