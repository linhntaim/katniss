<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2017-01-19
 * Time: 18:45
 */
return [
    'caption_image' => 'Nhập tiêu đề cho ảnh (nếu có)',
    'support_image' => 'Tập tin ảnh không được hỗ trợ:',
    'size_image' => 'Dung lượng tập tin ảnh quá lớn:',
    'caption_embed' => 'Nhập tiêu đề (nếu có)',
    'help_embed' => 'Sao chép và dán đường dẫn video trên YouTube hoặc Vimeo vào đây và ấn phím Enter',
];