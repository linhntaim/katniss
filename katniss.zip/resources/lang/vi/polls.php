<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-12-10
 * Time: 00:46
 */
return [
    'page_polls_title' => 'Mục bình chọn',
    'page_polls_desc' => 'Quản lý mục bình chọn',
    'page_poll_choices_title' => 'Bình chọn',
    'page_poll_choices_desc' => 'Quản lý bình chọn',
    'poll' => 'Mục bình chọn',
    'poll_lc' => 'mục bình chọn',
    'choice' => 'Bình chọn',
    'choice_lc' => 'bình chọn',
    'multi_choice' => 'Cho phép nhiều bình chọn',
    'votes' => 'Lượng bình chọn',
    'vote' => 'Lượt bình chọn',
    'vote_lc' => 'lượt bình chọn',
    'poll_not_empty' => 'Mục bình chọn không trống',
    'action_vote' => 'Bình chọn',
    'action_view_result' => 'Xem kết quả',
    'action_view_votes' => 'Thực hiện bình chọn',
    'must_select_one' => 'Bạn phải chọn ít nhất một kết quả để thực hiện bình chọn',
];