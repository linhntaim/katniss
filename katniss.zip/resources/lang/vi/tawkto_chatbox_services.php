<?php
/**
 * Created by PhpStorm.
 * User: daiduong47
 * Date: 14/01/2017
 * Time: 22:07 PM
 */
return [
    'enable' => 'Cho phép',
    'async' => 'Load không đồng bộ',
    'cache_enable' => 'Cho phép tạo tập tin tạm',
    'cache_enable_help' => 'Nếu được cho phép, các đoạn mã sẽ được lưu ra các tập tin tạm; nếu không, chúng sẽ được đặt trực tiếp trong trang web. Lưu ra tập tin tạm sẽ giúp giảm thời gian tải trang web của bạn.',
    'tawkto_chatbox_id' => 'Tawk.to chatbox id',
    'chatbox_id_guide' => 'Truy cập <a href=":url">Tawk.to</a> để tạo một tài khoản mới và lấy chatbox ID của bạn',
    'example' => 'Ví dụ',
    'chatbox_id_example_guide' => 'là chatbox ID của bạn',
];
