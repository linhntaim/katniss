<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2015-09-04
 * Time: 15:53
 */
return [
    'owner' => 'Chủ sở hữu',
    'admin' => 'Quản trị viên',
    'user' => 'Người dùng',
];