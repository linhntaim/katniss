<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-05-21
 * Time: 21:07
 */

return [
    'username' => 'Tên tài khoản',
    'num_of_items' => 'Số lượng hình ảnh',
    'num_of_columns' => 'Số lượng cột',
    'view_more' => 'Xem thêm',
];