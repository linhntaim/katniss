<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2017-01-08
 * Time: 13:22
 */
return [
    'page_theme_title' => 'Giao diện Wow Skype',
    'page_options_title' => 'Tùy chọn',
    'page_options_desc' => 'Quản lý tùy chọn giao diện',
    'world' => 'Thế giới WowSkype',

    'home_name' => 'Trang chủ - Tên ',
    'home_description' => 'Trang chủ - Lời mô tả',
    'site_keywords' => 'Từ khóa website',
    'home_email' => 'Trang chủ - Thư điện tử',
    'home_hot_line' => 'Trang chủ - Đường dây nóng',
    'social_sf' => 'Hiển thị tại cuối trang',
    'social_sb' => 'Hiển thị tại dưới cùng của trang',
    'social_facebook' => 'Facebook URL',
    'social_twitter' => 'Twitter URL',
    'social_instagram' => 'Instagram URL',
    'social_gplus' => 'Google Plus URL',
    'social_youtube' => 'Youtube URL',
    'social_skype' => 'Skype ID',
    'ts_skype_id' => 'Hỗ trợ giáo viên - ID tài khoản Skype',
    'ts_skype_name' => 'Hỗ trợ giáo viên - Tên tài khoản Skype',
    'ts_email' => 'Hỗ trợ giáo viên - Thư điện tử',
    'ts_hot_line' => 'Hỗ trợ giáo viên - Đường dây nóng',
    'ss_skype_id' => 'Hỗ trợ học viên - ID tài khoản Skype',
    'ss_skype_name' => 'Hỗ trợ học viên - Tên tài khoản Skype',
    'knowledge_cover_image' => 'Bìa ảnh trang kiến thức',
    'knowledge_default_article_image' => 'Ảnh mặc định cho bài viết',
];