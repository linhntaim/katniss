<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2015-11-19
 * Time: 14:55
 */
return [
    'enable' => 'Cho phép',
    'cache_enable' => 'Cho phép tạo tập tin tạm',
    'cache_enable_help' => 'Nếu được cho phép, các đoạn mã sẽ được lưu ra các tập tin tạm; nếu không, chúng sẽ được đặt trực tiếp trong trang web. Lưu ra tập tin tạm sẽ giúp giảm thời gian tải trang web của bạn.',
    'ga_async' => 'Tải các đoạn mã theo kiểu bất đồng bộ',
    'ga_async_help' => 'Bạn phải chắc chắn người dùng truy cập trang web của bạn trên các trình duyệt hiện đại',
];