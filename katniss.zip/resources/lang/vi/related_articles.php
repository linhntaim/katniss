<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2017-01-17
 * Time: 17:25
 */
return [
    'title' => 'Bài viết liên quan',
    'number_of_items' => 'Số lượng bài viết hiển thị',
];