<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2015-10-02
 * Time: 13:29
 */
return [
    '--' => 'Quốc tế',
    'VN' => 'Việt Nam',
];