<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2017-01-21
 * Time: 13:15
 */
return [
    'show_button' => 'Hiển thị nút Xem thêm',
    'show_articles' => 'Hiển thị tin mới nhất',
    'number_of_items' => 'Số lượng bài viết hiển thị',
];