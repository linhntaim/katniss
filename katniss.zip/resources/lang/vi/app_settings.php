<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-12-04
 * Time: 15:12
 */
return [
    'authentication' => 'Xác thực người dùng',
    'register_enable' => 'Cho phép người dùng đăng ký',
    'posts' => 'Bài viết',
    'default_article_category' => 'Chuyên mục mặc định cho chuyên đề',
    'short_code' => 'Short Code',
    'short_code_enable' => 'Cho phép short code hoạt động',
];