<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-12-12
 * Time: 20:44
 */
return [
    'page_map_markers_title' => 'Google Maps Markers',
    'page_map_markers_desc' => 'Manage Google Maps markers',
    'map_marker' => 'Đánh dấu bản đồ',
    'map_marker_lc' => 'đánh dấu bản đồ',
    'data' => 'Dữ liệu',
    'place_found' => 'Đia điểm đã được đánh dấu.',
    'place_not_found' => 'Không tìm thấy địa điểm.',
    'place_not_retrieved' => 'Địa điểm không thể xác định.',
    'map_help' => 'Hãy bấm vào bản đồ để tạo một điểm đánh dấu.',
];