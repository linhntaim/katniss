<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-05-21
 * Time: 21:07
 */

return [
    'username' => 'Username',
    'num_of_items' => 'Num of items',
    'num_of_columns' => 'Num of columns',
    'view_more' => 'Load more',
];