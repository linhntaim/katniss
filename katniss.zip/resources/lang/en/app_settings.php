<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-12-04
 * Time: 15:12
 */
return [
    'authentication' => 'Authentication',
    'register_enable' => 'Enable user registration',
    'posts' => 'Posts',
    'default_article_category' => 'Default article category',
    'short_code' => 'Short Code',
    'short_code_enable' => 'Enable short code parsing',
];