<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2017-01-17
 * Time: 17:25
 */
return [
    'title' => 'Related articles',
    'number_of_items' => 'Number of items',
];