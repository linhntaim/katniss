<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-05-21
 * Time: 21:07
 */

return [
    'exchange_rate' => 'Exchange rate|Exchange rates',
    'main_currency' => 'Main currency',
    'change_here' => '<a href=":url">Change here</a>'
];