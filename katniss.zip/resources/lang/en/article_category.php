<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2017-01-21
 * Time: 13:15
 */
return [
    'show_button' => 'Show button',
    'show_articles' => 'Show articles',
    'number_of_items' => 'Number of items',
];