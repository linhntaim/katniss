<?php
/**
 * Created by PhpStorm.
 * User: daiduong47
 * Date: 14/01/2017
 * Time: 22:07 PM
 */
return [
    'enable' => 'Enable',
    'async' => 'Asynchronous',
    'cache_enable' => 'Cache Enable',
    'cache_enable_help' => 'If enable, scripts are in cached js files; if not, they are put inline. Cache slightly helps to decrease load time of web pages',
    'tawkto_chatbox_id' => 'Tawk.to chat box id',
    'chatbox_id_guide' => 'Go to the <a href=":url">Tawk.to</a> to create a new account and get your chatbox ID',
    'example' => 'Example',
    'chatbox_id_example_guide' => 'is your chatbox ID',
];
