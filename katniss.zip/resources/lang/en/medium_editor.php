<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2017-01-19
 * Time: 18:45
 */
return [
    'caption_image' => 'Type caption for image (optional)',
    'support_image' => 'This file is not in a supported format:',
    'size_image' => 'This file is too big:',
    'caption_embed' => 'Type caption (optional)',
    'help_embed' => 'Paste a YouTube or Vimeo link and press Enter',
];