<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-12-09
 * Time: 00:07
 */
return [
    'page_contact_forms_title' => 'Contact Form',
    'page_contact_forms_desc' => 'Manage contact form data',
    'contact_form' => 'Contact form|Contact forms',
];