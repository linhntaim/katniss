<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2016-12-12
 * Time: 20:44
 */
return [
    'page_map_markers_title' => 'Google Maps Markers',
    'page_map_markers_desc' => 'Manage Google Maps markers',
    'map_marker' => 'Map marker|Map markers',
    'map_marker_lc' => 'map marker|map markers',
    'data' => 'Data',
    'place_found' => 'Place found.',
    'place_not_found' => 'Place not found.',
    'place_not_retrieved' => 'Place not located.',
    'map_help' => 'Please click on map to add a marker.',
];