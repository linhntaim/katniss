<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2015-11-19
 * Time: 14:55
 */
return [
    'enable' => 'Enable',
    'cache_enable' => 'Cache Enable',
    'cache_enable_help' => 'If enable, scripts are in cached js files; if not, they are put inline. Cache slightly helps to decrease load time of web pages',
    'ga_async' => 'Use async script',
    'ga_async_help' => 'You must ensure all your users access website on modern browsers',
];