<?php
/**
 * Created by PhpStorm.
 * User: Nguyen Tuan Linh
 * Date: 2015-09-04
 * Time: 15:53
 */
return [
    'owner' => 'Owner',
    'admin' => 'Administrator',
    'user' => 'User',
];