<?php

class DigitalPointBetterAnalytics_Base_Pro
{
	public static $installed = false;
	public static $version = null;


	public static function track_blocked()
	{
	}
}