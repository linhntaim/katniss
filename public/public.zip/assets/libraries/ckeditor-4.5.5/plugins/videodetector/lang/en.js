/**
 * Created by Nguyen Tuan Linh on 2015-11-19.
 */
CKEDITOR.plugins.setLang('videodetector', 'en', {
    title : 'Insert a Youtube, Vimeo or Dailymotion URL',
    basic_settings : 'Basic Settings',
    url_video_label : 'Youtube, Vimeo  or Dailymotion URL',
    empty : 'Empty!'
});